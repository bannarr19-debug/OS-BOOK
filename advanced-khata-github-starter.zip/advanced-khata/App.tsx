import React, { useEffect, useMemo, useState } from "react";
import {
  Alert, SafeAreaView, ScrollView, StatusBar, StyleSheet, Text, TextInput,
  TouchableOpacity, View, ActivityIndicator
} from "react-native";
import { StatusBar as ExpoStatusBar } from "expo-status-bar";
import * as WebBrowser from "expo-web-browser";
import * as Google from "expo-auth-session/providers/google";
import { GoogleAuthProvider, onAuthStateChanged, signInWithCredential, signOut, User } from "firebase/auth";
import {
  addDoc, collection, deleteDoc, doc, onSnapshot, orderBy, query, serverTimestamp,
  updateDoc, where
} from "firebase/firestore";
import { auth, db } from "./firebase";

WebBrowser.maybeCompleteAuthSession();

type Customer = { id: string; name: string; phone?: string; createdAt?: any };
type Tx = {
  id: string; customerId: string; customerName: string; type: "udhar" | "jama";
  amount: number; note: string; createdAt?: any; createdAtMs: number;
};
type Trip = {
  id: string; vehicle: string; km: number; ratePerKm: number; mileage: number;
  fuelPrice: number; manualFuelCost?: number; otherCost: number; income: number;
  fuelCost: number; profit: number; createdAtMs: number; note: string;
};

const navy = "#101827", panel = "#192538", gold = "#E5B85C", muted = "#A8B4C5";
const money = (n: number) => "₹" + Math.round(n).toLocaleString("en-IN");
const now = () => Date.now();

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [txs, setTxs] = useState<Tx[]>([]);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [tab, setTab] = useState<"home" | "customers" | "water" | "reports">("home");
  const [period, setPeriod] = useState("20h");
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [selected, setSelected] = useState<Customer | null>(null);
  const [amount, setAmount] = useState("");
  const [txType, setTxType] = useState<"udhar" | "jama">("udhar");
  const [note, setNote] = useState("");
  const [vehicle, setVehicle] = useState("Vehicle 1");
  const [km, setKm] = useState("100");
  const [mileage, setMileage] = useState("10");
  const [rate, setRate] = useState("30");
  const [fuelPrice, setFuelPrice] = useState("100");
  const [manualFuel, setManualFuel] = useState("");
  const [otherCost, setOtherCost] = useState("0");
  const [fuelMode, setFuelMode] = useState<"auto" | "manual">("auto");
  const [tripNote, setTripNote] = useState("");
  const [googleRequest, googleResponse, promptGoogle] = Google.useIdTokenAuthRequest({
    // Add your Firebase project's Web client ID and Android OAuth client ID here.
    clientId: "PASTE_WEB_CLIENT_ID.apps.googleusercontent.com",
    androidClientId: "PASTE_ANDROID_CLIENT_ID.apps.googleusercontent.com"
  });

  useEffect(() => onAuthStateChanged(auth, u => { setUser(u); setLoading(false); }), []);
  useEffect(() => {
    if (!user) { setCustomers([]); setTxs([]); setTrips([]); return; }
    const c = onSnapshot(query(collection(db, "users", user.uid, "customers"), orderBy("name")),
      s => setCustomers(s.docs.map(d => ({ id: d.id, ...d.data() } as Customer))));
    const t = onSnapshot(query(collection(db, "users", user.uid, "transactions"), orderBy("createdAtMs", "desc")),
      s => setTxs(s.docs.map(d => ({ id: d.id, ...d.data() } as Tx))));
    const w = onSnapshot(query(collection(db, "users", user.uid, "trips"), orderBy("createdAtMs", "desc")),
      s => setTrips(s.docs.map(d => ({ id: d.id, ...d.data() } as Trip))));
    return () => { c(); t(); w(); };
  }, [user]);

  useEffect(() => {
    if (googleResponse?.type === "success") {
      const idToken = googleResponse.params.id_token;
      if (idToken) signInWithCredential(auth, GoogleAuthProvider.credential(idToken))
        .catch(e => Alert.alert("Login error", e.message));
    }
  }, [googleResponse]);

  const periodMs = useMemo(() => {
    const map: Record<string, number> = {
      "1h": 3600000, "5h": 18000000, "10h": 36000000, "20h": 72000000,
      "24h": 86400000, "48h": 172800000, "72h": 259200000,
      "7d": 604800000, "30d": 2592000000, "6m": 15552000000, "1y": 31536000000
    };
    return period === "all" ? 0 : map[period] ?? 72000000;
  }, [period]);
  const filteredTx = txs.filter(t => !periodMs || t.createdAtMs >= now() - periodMs);
  const filteredTrips = trips.filter(t => !periodMs || t.createdAtMs >= now() - periodMs);
  const udhar = filteredTx.filter(t => t.type === "udhar").reduce((a,t) => a+t.amount, 0);
  const jama = filteredTx.filter(t => t.type === "jama").reduce((a,t) => a+t.amount, 0);
  const tripIncome = filteredTrips.reduce((a,t) => a+t.income, 0);
  const tripCosts = filteredTrips.reduce((a,t) => a+t.fuelCost+t.otherCost, 0);
  const profit = filteredTrips.reduce((a,t) => a+t.profit, 0);

  async function addCustomer() {
    if (!user || !name.trim()) return Alert.alert("Name required", "Customer ka naam likhiye.");
    try {
      await addDoc(collection(db, "users", user.uid, "customers"), {
        name: name.trim(), phone: phone.trim(), createdAt: serverTimestamp()
      });
      setName(""); setPhone(""); Alert.alert("Saved", "Customer add ho gaya.");
    } catch (e:any) { Alert.alert("Error", e.message); }
  }
  async function addTransaction() {
    if (!user || !selected) return;
    const value = Number(amount);
    if (!Number.isFinite(value) || value <= 0) return Alert.alert("Invalid amount", "Sahi amount dalein.");
    try {
      await addDoc(collection(db, "users", user.uid, "transactions"), {
        customerId: selected.id, customerName: selected.name, type: txType,
        amount: value, note: note.trim(), createdAt: serverTimestamp(), createdAtMs: now()
      });
      setAmount(""); setNote(""); Alert.alert("Saved", "Transaction save ho gaya.");
    } catch (e:any) { Alert.alert("Error", e.message); }
  }
  async function addTrip() {
    if (!user) return;
    const distance=Number(km), mpg=Number(mileage), perKm=Number(rate), fuel=Number(fuelPrice), other=Number(otherCost);
    if ([distance,mpg,perKm,fuel,other].some(v => !Number.isFinite(v) || v < 0) || mpg <= 0)
      return Alert.alert("Invalid details", "KM, mileage, rate, fuel price aur expenses check karein.");
    const income=distance*perKm;
    const fuelCost=fuelMode === "manual" ? Number(manualFuel) : (distance/mpg)*fuel;
    if (!Number.isFinite(fuelCost) || fuelCost < 0) return Alert.alert("Invalid fuel cost", "Petrol cost sahi dalein.");
    const item: Omit<Trip,"id"> = {
      vehicle: vehicle.trim() || "Vehicle 1", km: distance, ratePerKm: perKm, mileage: mpg,
      fuelPrice: fuel, manualFuelCost: fuelMode === "manual" ? fuelCost : undefined,
      otherCost: other, income, fuelCost, profit: income-fuelCost-other,
      createdAtMs: now(), note: tripNote.trim()
    };
    try {
      await addDoc(collection(db, "users", user.uid, "trips"), item);
      setTripNote(""); Alert.alert("Trip saved", `Estimated profit: ${money(item.profit)}`);
    } catch (e:any) { Alert.alert("Error", e.message); }
  }

  if (loading) return <SafeAreaView style={s.center}><ActivityIndicator color={gold}/></SafeAreaView>;
  if (!user) return <SafeAreaView style={s.container}>
    <ExpoStatusBar style="light"/>
    <View style={s.login}>
      <Text style={s.brand}>ADVANCED KHATA</Text>
      <Text style={s.hero}>Your business.{'\n'}One clear account.</Text>
      <Text style={s.sub}>Customer ledger • Water supply • Profit reports</Text>
      <TouchableOpacity style={s.primary} disabled={!googleRequest} onPress={() => promptGoogle()}>
        <Text style={s.primaryText}>Continue with Google</Text>
      </TouchableOpacity>
      <Text style={s.hint}>Sign-in setup ke liye Firebase aur Google OAuth IDs add karna zaroori hai.</Text>
    </View>
  </SafeAreaView>;

  return <SafeAreaView style={s.container}>
    <ExpoStatusBar style="light"/>
    <View style={s.header}>
      <View><Text style={s.brand}>ADVANCED KHATA</Text><Text style={s.sub}>Premium business ledger</Text></View>
      <TouchableOpacity onPress={() => signOut(auth)}><Text style={s.link}>Logout</Text></TouchableOpacity>
    </View>
    <View style={s.tabs}>
      {(["home","customers","water","reports"] as const).map(v =>
        <TouchableOpacity key={v} onPress={() => {setTab(v);setSelected(null);}} style={[s.tab,tab===v&&s.tabOn]}>
          <Text style={[s.tabText,tab===v&&s.tabTextOn]}>{v==="home"?"Home":v==="customers"?"Khata":v==="water"?"Water": "Reports"}</Text>
        </TouchableOpacity>)}
    </View>
    <ScrollView contentContainerStyle={s.content}>
      {tab==="home" && <>
        <Text style={s.heading}>Overview</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{marginBottom:14}}>
          {[
            ["1h","1 Hour"],["5h","5 Hours"],["10h","10 Hours"],["20h","20 Hours"],
            ["24h","24 Hours"],["48h","48 Hours"],["72h","72 Hours"],["7d","7 Days"],
            ["30d","30 Days"],["6m","6 Months"],["1y","1 Year"],["all","All Time"]
          ].map(([v,l])=><TouchableOpacity key={v} onPress={()=>setPeriod(v)} style={[s.chip,period===v&&s.chipOn]}><Text style={[s.chipText,period===v&&s.chipTextOn]}>{l}</Text></TouchableOpacity>)}
        </ScrollView>
        <View style={s.grid}>
          <Metric title="Udhar added" value={money(udhar)}/>
          <Metric title="Jama received" value={money(jama)}/>
          <Metric title="Khata balance" value={money(udhar-jama)}/>
          <Metric title="Customers" value={String(customers.length)}/>
          <Metric title="Water income" value={money(tripIncome)}/>
          <Metric title="Water expenses" value={money(tripCosts)}/>
          <Metric title="Estimated profit" value={money(profit)} wide/>
        </View>
        <Text style={s.section}>Recent activity</Text>
        {filteredTx.slice(0,8).map(t=><View key={t.id} style={s.listRow}><View style={{flex:1}}><Text style={s.rowTitle}>{t.customerName}</Text><Text style={s.muted}>{t.type.toUpperCase()} • {new Date(t.createdAtMs).toLocaleString()}</Text></View><Text style={[s.amount,t.type==="jama"?s.green:s.red]}>{money(t.amount)}</Text></View>)}
        {filteredTx.length===0&&<Text style={s.muted}>Selected time range mein koi khata transaction nahi hai.</Text>}
      </>}
      {tab==="customers" && <>
        <Text style={s.heading}>Customer Khata</Text>
        {!selected ? <>
          <TextInput style={s.input} placeholder="Customer name" placeholderTextColor={muted} value={name} onChangeText={setName}/>
          <TextInput style={s.input} placeholder="Mobile number (optional)" placeholderTextColor={muted} keyboardType="phone-pad" value={phone} onChangeText={setPhone}/>
          <TouchableOpacity style={s.primary} onPress={addCustomer}><Text style={s.primaryText}>+ Add Customer</Text></TouchableOpacity>
          <Text style={s.section}>All customers ({customers.length})</Text>
          {customers.map(c=>{
            const bal=txs.filter(t=>t.customerId===c.id).reduce((a,t)=>a+(t.type==="udhar"?t.amount:-t.amount),0);
            return <TouchableOpacity key={c.id} style={s.listRow} onPress={()=>setSelected(c)}>
              <View style={{flex:1}}><Text style={s.rowTitle}>{c.name}</Text><Text style={s.muted}>{c.phone||"No phone number"}</Text></View>
              <Text style={s.amount}>{money(bal)}  ›</Text>
            </TouchableOpacity>;
          })}
        </> : <>
          <TouchableOpacity onPress={()=>setSelected(null)}><Text style={s.link}>‹ All customers</Text></TouchableOpacity>
          <Text style={s.heading}>{selected.name}</Text>
          <Text style={s.muted}>{selected.phone||"No phone number"}</Text>
          <View style={s.card}><Text style={s.muted}>Current balance (udhar − jama)</Text><Text style={s.big}>{money(txs.filter(t=>t.customerId===selected.id).reduce((a,t)=>a+(t.type==="udhar"?t.amount:-t.amount),0))}</Text></View>
          <View style={s.row}>
            <TouchableOpacity style={[s.primary,{flex:1}]} onPress={()=>{setTxType("udhar");setAmount("");}}><Text style={s.primaryText}>Add Udhar</Text></TouchableOpacity>
            <TouchableOpacity style={[s.secondary,{flex:1}]} onPress={()=>{setTxType("jama");setAmount("");}}><Text style={s.primaryText}>Add Jama</Text></TouchableOpacity>
          </View>
          <Text style={s.section}>New {txType==="udhar"?"Udhar":"Jama"} entry</Text>
          <TextInput style={s.input} placeholder="Amount ₹" placeholderTextColor={muted} keyboardType="decimal-pad" value={amount} onChangeText={setAmount}/>
          <TextInput style={s.input} placeholder="Note (optional)" placeholderTextColor={muted} value={note} onChangeText={setNote}/>
          <TouchableOpacity style={s.primary} onPress={addTransaction}><Text style={s.primaryText}>Save transaction</Text></TouchableOpacity>
          <Text style={s.section}>Full history</Text>
          {txs.filter(t=>t.customerId===selected.id).map(t=><View key={t.id} style={s.listRow}><View style={{flex:1}}><Text style={s.rowTitle}>{t.type==="udhar"?"Udhar":"Jama"} • {new Date(t.createdAtMs).toLocaleString()}</Text><Text style={s.muted}>{t.note}</Text></View><Text style={s.amount}>{money(t.amount)}</Text></View>)}
        </>}
      </>}
      {tab==="water" && <>
        <Text style={s.heading}>Water Supply</Text>
        <Text style={s.muted}>Default: 10 KM/L • ₹30 earning per KM • Auto or manual fuel cost</Text>
        <Text style={s.section}>Trip details</Text>
        <TextInput style={s.input} placeholder="Vehicle name / number" placeholderTextColor={muted} value={vehicle} onChangeText={setVehicle}/>
        <TextInput style={s.input} placeholder="Distance in KM" placeholderTextColor={muted} keyboardType="decimal-pad" value={km} onChangeText={setKm}/>
        <TextInput style={s.input} placeholder="Mileage KM per litre" placeholderTextColor={muted} keyboardType="decimal-pad" value={mileage} onChangeText={setMileage}/>
        <TextInput style={s.input} placeholder="Earning per KM ₹" placeholderTextColor={muted} keyboardType="decimal-pad" value={rate} onChangeText={setRate}/>
        <TextInput style={s.input} placeholder="Petrol price per litre ₹" placeholderTextColor={muted} keyboardType="decimal-pad" value={fuelPrice} onChangeText={setFuelPrice}/>
        <View style={s.row}>
          <TouchableOpacity style={[s.chip,fuelMode==="auto"&&s.chipOn]} onPress={()=>setFuelMode("auto")}><Text style={s.chipText}>Auto fuel</Text></TouchableOpacity>
          <TouchableOpacity style={[s.chip,fuelMode==="manual"&&s.chipOn]} onPress={()=>setFuelMode("manual")}><Text style={s.chipText}>Manual fuel</Text></TouchableOpacity>
        </View>
        {fuelMode==="manual"&&<TextInput style={s.input} placeholder="Actual petrol cost ₹" placeholderTextColor={muted} keyboardType="decimal-pad" value={manualFuel} onChangeText={setManualFuel}/>}
        <TextInput style={s.input} placeholder="Other expenses ₹" placeholderTextColor={muted} keyboardType="decimal-pad" value={otherCost} onChangeText={setOtherCost}/>
        <TextInput style={s.input} placeholder="Trip note (optional)" placeholderTextColor={muted} value={tripNote} onChangeText={setTripNote}/>
        <View style={s.card}>
          <Text style={s.muted}>Estimated trip calculation</Text>
          <Text style={s.rowTitle}>Income: {money((Number(km)||0)*(Number(rate)||0))}</Text>
          <Text style={s.rowTitle}>Fuel: {money(fuelMode==="manual"?(Number(manualFuel)||0):((Number(km)||0)/(Number(mileage)||10))*(Number(fuelPrice)||0))}</Text>
          <Text style={s.big}>Profit: {money((Number(km)||0)*(Number(rate)||0)-(fuelMode==="manual"?(Number(manualFuel)||0):((Number(km)||0)/(Number(mileage)||10))*(Number(fuelPrice)||0)-(0))-(Number(otherCost)||0))}</Text>
        </View>
        <TouchableOpacity style={s.primary} onPress={addTrip}><Text style={s.primaryText}>Save Trip</Text></TouchableOpacity>
        <Text style={s.section}>Trip history</Text>
        {trips.map(t=><View key={t.id} style={s.listRow}><View style={{flex:1}}><Text style={s.rowTitle}>{t.vehicle} • {t.km} KM</Text><Text style={s.muted}>{new Date(t.createdAtMs).toLocaleString()} • Fuel {money(t.fuelCost)}</Text></View><Text style={s.amount}>{money(t.profit)}</Text></View>)}
      </>}
      {tab==="reports" && <>
        <Text style={s.heading}>Reports</Text>
        <Text style={s.muted}>Selected period: {period}</Text>
        <View style={s.grid}>
          <Metric title="Khata udhar" value={money(udhar)}/>
          <Metric title="Khata jama" value={money(jama)}/>
          <Metric title="Net khata" value={money(udhar-jama)}/>
          <Metric title="Water income" value={money(tripIncome)}/>
          <Metric title="Water expenses" value={money(tripCosts)}/>
          <Metric title="Water profit" value={money(profit)}/>
        </View>
        <Text style={s.hint}>Note: Water trip profit is estimated from the trip's entered distance, rate, fuel and other expenses. Customer khata and trip profit are shown separately to avoid double-counting.</Text>
      </>}
    </ScrollView>
  </SafeAreaView>;
}

function Metric({title,value,wide=false}:{title:string;value:string;wide?:boolean}) {
  return <View style={[s.metric,wide&&{width:"100%"}]}><Text style={s.muted}>{title}</Text><Text style={s.metricValue}>{value}</Text></View>;
}

const s=StyleSheet.create({
  container:{flex:1,backgroundColor:navy}, center:{flex:1,backgroundColor:navy,alignItems:"center",justifyContent:"center"},
  login:{flex:1,justifyContent:"center",padding:26}, header:{paddingHorizontal:20,paddingTop:14,paddingBottom:12,flexDirection:"row",justifyContent:"space-between",alignItems:"center"},
  brand:{color:gold,fontSize:13,fontWeight:"900",letterSpacing:2}, hero:{color:"#F6F7FB",fontSize:34,fontWeight:"800",marginTop:35,lineHeight:42},
  sub:{color:muted,fontSize:13,marginTop:6}, hint:{color:muted,fontSize:12,lineHeight:18,marginTop:14},
  primary:{backgroundColor:gold,borderRadius:13,padding:15,alignItems:"center",justifyContent:"center",marginTop:12},
  secondary:{backgroundColor:"#31445F",borderRadius:13,padding:15,alignItems:"center",justifyContent:"center",marginTop:12},
  primaryText:{color:"#151B25",fontWeight:"800"}, link:{color:gold,fontWeight:"700"}, tabs:{flexDirection:"row",paddingHorizontal:12,gap:6},
  tab:{flex:1,paddingVertical:11,borderRadius:10,alignItems:"center"},tabOn:{backgroundColor:panel},tabText:{color:muted,fontSize:12,fontWeight:"700"},tabTextOn:{color:gold},
  content:{padding:16,paddingBottom:40},heading:{color:"#F7F8FA",fontSize:24,fontWeight:"800",marginBottom:14},
  chip:{backgroundColor:panel,paddingVertical:9,paddingHorizontal:12,borderRadius:20,marginRight:7},
  chipOn:{backgroundColor:gold},chipText:{color:"#EAF0F7",fontSize:12,fontWeight:"700"},chipTextOn:{color:"#18202C"},
  grid:{flexDirection:"row",flexWrap:"wrap",justifyContent:"space-between",gap:10},
  metric:{width:"48%",backgroundColor:panel,borderRadius:14,padding:14,minHeight:82,justifyContent:"space-between"},
  metricValue:{color:"#F8F9FC",fontSize:20,fontWeight:"800",marginTop:8},section:{color:gold,fontWeight:"800",fontSize:15,marginTop:22,marginBottom:10},
  listRow:{backgroundColor:panel,padding:14,borderRadius:12,marginBottom:8,flexDirection:"row",alignItems:"center",gap:10},
  rowTitle:{color:"#F4F6FA",fontWeight:"700",fontSize:14},muted:{color:muted,fontSize:11,marginTop:3},
  amount:{color:"#F5F6F9",fontWeight:"800"},green:{color:"#54D6A0"},red:{color:"#FF8B8B"},
  input:{backgroundColor:panel,borderRadius:12,padding:14,color:"#FFFFFF",marginBottom:10,fontSize:14},
  card:{backgroundColor:panel,borderRadius:14,padding:16,marginVertical:12},big:{color:gold,fontSize:27,fontWeight:"900",marginTop:7},
  row:{flexDirection:"row",gap:10,alignItems:"center",marginTop:6}
});