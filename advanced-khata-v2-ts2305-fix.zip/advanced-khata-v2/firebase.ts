import { initializeApp, getApps } from "firebase/app";
import * as FirebaseAuth from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import AsyncStorage from "@react-native-async-storage/async-storage";

const firebaseConfig = {
  apiKey: "PASTE_API_KEY",
  authDomain: "PASTE_PROJECT_ID.firebaseapp.com",
  projectId: "PASTE_PROJECT_ID",
  storageBucket: "PASTE_PROJECT_ID.appspot.com",
  messagingSenderId: "PASTE_SENDER_ID",
  appId: "PASTE_APP_ID"
};

export const firebaseConfigured =
  !firebaseConfig.apiKey.startsWith("PASTE_") &&
  !firebaseConfig.projectId.startsWith("PASTE_") &&
  !firebaseConfig.appId.startsWith("PASTE_");

const app = getApps().length ? getApps()[0] : initializeApp(firebaseConfig);

type ReactNativePersistenceFactory = (
  storage: typeof AsyncStorage
) => unknown;

// Access the React Native-specific export through the module namespace.
// This avoids TS2305 when the package's public type declarations omit it.
const getReactNativePersistence = (
  FirebaseAuth as unknown as {
    getReactNativePersistence?: ReactNativePersistenceFactory;
  }
).getReactNativePersistence;

function createAuth() {
  if (getReactNativePersistence) {
    try {
      return FirebaseAuth.initializeAuth(app, {
        persistence: getReactNativePersistence(AsyncStorage) as never
      });
    } catch {
      // Auth may already have been initialized during Fast Refresh.
      return FirebaseAuth.getAuth(app);
    }
  }

  // Safe fallback: app can start, but durable sign-in persistence
  // must be verified on-device before treating cloud login as complete.
  return FirebaseAuth.getAuth(app);
}

export const auth = createAuth();
export const db = getFirestore(app);
