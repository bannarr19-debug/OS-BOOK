# Advanced Khata (Android)

Premium starter app for customer udhar/jama ledger and water-supply trip profitability.

## Included
- Google sign-in flow using Expo AuthSession + Firebase Authentication
- Per-user Firestore cloud data
- Customer ledger: udhar, jama, running balance, timestamped history
- Dashboard filters: 1h, 5h, 10h, 20h, 24h, 48h, 72h, 7d, 30d, 6m, 1y, all-time
- Water supply trips: vehicle, KM, default 10 KM/L, default ₹30/KM
- Automatic fuel estimate OR manual actual fuel cost
- Other trip expenses and estimated profit
- GitHub Actions APK build workflow

## Important setup before first working build
This repository is source code; Firebase and Google OAuth credentials must be configured by the app owner.

1. Create a Firebase project at https://console.firebase.google.com/
2. Add a **Web app** in Firebase and copy its config into `firebase.ts`.
3. Enable **Authentication > Sign-in method > Google**.
4. Create a Firestore database and publish `firestore.rules`.
5. In Google Cloud Console, configure OAuth consent screen and create OAuth client IDs:
   - Web client ID: paste into `clientId` in `App.tsx`.
   - Android client ID: paste into `androidClientId` in `App.tsx`.
   - For Android OAuth, use package name `com.advancedkhata.app` and the SHA-1 certificate fingerprint from the Android build/signing setup.
6. Never commit private service-account JSON, keystores, passwords, or tokens.

## GitHub APK build
1. Create a **private** GitHub repository named `advanced-khata`.
2. Upload all files from this project, including the hidden `.github` folder.
3. Open **Actions** and run `Build Android APK` (or push to `main`).
4. Download `advanced-khata-release-apk` from the completed workflow's Artifacts section.

## Local development
```bash
npm install
npm run typecheck
npx expo start
```

## Data and calculation notes
- Customer balance = total udhar minus total jama.
- Dashboard's selected time window filters transaction/trip totals; customer count is the current total.
- Trip income = KM × earning per KM.
- Auto fuel cost = (KM ÷ mileage) × fuel price per litre.
- Manual fuel mode uses the actual fuel cost entered.
- Trip estimated profit = income − fuel cost − other expenses.
- Customer ledger and trip profit remain separate to prevent accidental double-counting.

## Current limitations / next development items
- Add edit/void audit history for financial records before production use.
- Add PDF/CSV export, WhatsApp share, custom date range, vehicle management and optional linking of trip invoices to customer balances.
- Add App Check, stronger Firestore validation, backup/export and production OAuth verification before real business deployment.

## V2 startup safeguards
- React Error Boundary shows render-time JavaScript errors in the app.
- Firebase Auth uses AsyncStorage persistence on React Native.
- Missing Firebase credentials show a setup screen rather than attempting Google login.
- GitHub Actions checks TypeScript and Expo configuration before Android compilation.

Important: this does not guarantee zero errors. A native Android crash can happen before React renders; if that occurs, Android crash logs are still needed.

## Firebase Auth TypeScript correction
The Firebase Auth module is accessed through a namespace and a guarded React Native persistence lookup to avoid TS2305 when the installed Firebase type declarations omit `getReactNativePersistence`. Verify persistent sign-in on a device before production use; the fallback starts safely but does not guarantee durable sign-in.
